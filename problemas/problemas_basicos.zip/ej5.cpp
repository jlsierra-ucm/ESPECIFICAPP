#include "especificapp.h"

#include <iostream>

using namespace std;

// Un vector no vac�o de enteros es exc�ntrico cuando, si su primer valor es 0, entonces tiene al 
// menos otro 0, pero si no es 0, ese primer valor no vuelve a repetirse. Dado un vector almacenado 
// en las n primeras posiciones del array a, especifica un predicado que sea cierto cuando el vector 
// es exc�ntrico, y falso en caso contrario.


bool es_excentrico(int a[], int n) {
    // DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}

// PROGRAMA DE PRUEBA: NO MODIFICAR

//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        5
//        0 1 2 0 4
//        5
//        0 1 2 3 4
//        5
//        1 -1 2 3 4
//        5
//        1 -1 1 3 4
//        -1
//      SALIDA:
//       true
//       false
//       true
//       false  


// PROGRAMA DE PRUEBA: NO MODIFICAR

const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[]) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 if (lee_caso(n, a)) {
		 cout << std::boolalpha << es_excentrico(a, n) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

