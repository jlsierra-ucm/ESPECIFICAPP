#include "especificapp.h"

#include <iostream>

using namespace std;

   // El rango de un vector es el n�mero de elementos distintos que tiene. 
   // Dado un vector de n elementos de enteros almacenado en las n primeras 
   // posiciones de un array a, y una variable entera r, especifica un predicado 
   // que sea cierto cuando r contiene el rango de a, y falso en caso contrario.


bool es_rango(int a[], int n, int r) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES     
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}

// PROGRAMA DE PRUEBA: NO MODIFICAR


//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//      Valor de r
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        5
//        1 2 3 4 5
//        5
//        5
//        1 2 1 3 1
//        5
//        5
//        1 2 1 3 1
//        3
//        1
//        1
//        1  
//        -1
//      SALIDA:
//       true
//       false
//       true
//       true  



const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int& r) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		cin >> r;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 int r;
	 if (lee_caso(n, a, r)) {
		 cout << std::boolalpha << es_rango(a, n ,r) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

