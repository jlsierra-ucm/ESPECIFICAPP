#include "especificapp.h"

#include <iostream>

using namespace std;

    // Se tienen dos vectores de n elementos, almacenados, respectivamente, en 
	// las n primeras posiciones de los arrays a y b. Especifica un predicado que 
	// sea cierto cuando el vector en a es una permutaci�n del vector en b, y falso en 
	// caso contrario.


bool es_permutacion(int a[], int b[], int n) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
	
}


// PROGRAMA DE PRUEBA: NO MODIFICAR


//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//      Elem1 ... Elemk del vector 'b'
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//       5
//       1 2 3 4 5
//       5 1 3 2 4
//       5
//       1 2 3 4 5
//       5 1 1 2 4
//       4
//       4 1 2 3
//       5 3 2 1
//       6
//       5 4 3 2 1 6
//       1 2 3 4 5 6
//       -1
//      SALIDA:
//       true
//       false
//       false
//       true  


const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int b[]) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		for (int i = 0; i < n; i++) {
			cin >> b[i];
		}
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int b[N];
	 int n;
	 if (lee_caso(n, a, b)) {
		 cout << std::boolalpha << es_permutacion(a, b, n) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

