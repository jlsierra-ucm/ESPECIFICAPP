#include "especificapp.h"

#include <iostream>

using namespace std;

// Se tiene un vector no vac�o de n elementos, almacenado en las n primeras posiciones de un array a. 
// Se tiene tambi�n dos variables enteras s y k. Especifica un predicado que sea cierto cuando s es 
// la suma m�s peque�a que puede obtenerse sumando k valores consecutivos en el vector.


bool es_min_k_suma(int a[], int n, int k, int s) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}


// PROGRAMA DE PRUEBA: NO MODIFICAR

//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//      Valor de k
//      Valor de s
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        5
//        1 2 3 4 5
//        3
//        6
//        5
//        1 2 3 4 -5
//        2
//        -1
//        5
//        1 2 3 4 5
//        2
//        9
//        4
//        1 2 3 4
//        1
//        1
//        -1
//      SALIDA:
//       true
//       true
//       false
//       true  


const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int & k, int & s) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		cin >> k;
		cin >> s;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 int k;
	 int s;
	 if (lee_caso(n, a, k, s)) {
		 cout << std::boolalpha << es_min_k_suma(a, n, k, s) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

