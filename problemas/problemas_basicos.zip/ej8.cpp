#include "especificapp.h"

#include <iostream>

using namespace std;

    // El producto escalar de dos vectores de dimensi�n n es la suma de los productos de sus componentes. 
	// Dados dos vectores de enteros de dimensi�n n almacenados, respectivamente, en la n primeras posiciones 
	// de los arrays a y b, y dada una variable entera p, especifica un predicado que sea cierto cuando p es 
	// el producto escalar de los dos vectores, y falso en caso contrario.


bool es_prod_esc(int a[], int b[], int n, int p) {
    // DEFINE AQUI EL PREDICADO PEDIDO. PUEDES     
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}


// PROGRAMA DE PRUEBA: NO MODIFICAR

//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//      Elem1 ... Elemk del vector 'b'
//      Valor de p
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        5
//        1 2 3 4 5
//        5 1 3 2 4
//        44
//        3
//        1 2 3
//        1 0 2
//        7
//        3
//        1 0 0
//        0 1 0
//        0
//        4
//        1 0 0 0 
//        0 0 0 1
//        1
//        -1
//      SALIDA:
//       true
//       true
//       true
//       false  



const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int b[], int& p) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		for (int i = 0; i < n; i++) {
			cin >> b[i];
		}
		cin >> p;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int b[N];
	 int n;
	 int p;
	 if (lee_caso(n, a, b, p)) {
		 cout << std::boolalpha << es_prod_esc(a, b, n ,p) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

