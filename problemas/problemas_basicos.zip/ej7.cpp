#include "especificapp.h"

#include <iostream>

using namespace std;

    // Un vector de enteros es c�ncavo cuando es de la forma Alpha v Beta, con Alpha y Beta secuencias no vac�as
	// de enteros, Alpha v una secuencia de enteros estrictamente creciente, y v Beta una secuencia de enteros 
	// estrictamente decreciente. Dado un vector almacenado en las n primeras posiciones del array a, especifica 
	// un predicado que sea cierto cuando el vector es c�ncavo, y falso en caso contrario.


// PROGRAMA DE PRUEBA: NO MODIFICAR

bool es_concavo(int a[], int n) {
    // DEFINE AQUI EL PREDICADO PEDIDO. PUEDES     
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}


//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        5
//        1 2 3 2 1
//        5
//        1 2 3 4 5
//        6
//        1 2 3 2 1 2
//        4
//        4 3 2 1
//        -1
//      SALIDA:
//       true
//       false
//       false
//       false  



const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[]) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 if (lee_caso(n, a)) {
		 cout << std::boolalpha << es_concavo(a, n) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

