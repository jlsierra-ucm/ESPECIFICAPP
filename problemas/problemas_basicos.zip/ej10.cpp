#include "especificapp.h"

#include <iostream>

using namespace std;

  // Dado un vector de n elementos de enteros almacenado en las n primeras 
  // posiciones de un array a, y una variable entera c, especifica un predicado 
  // que sea cierto cuando c contiene el n�mero de tramos constantes 
  // (repeticiones consecutivas de un mismo valor) de longitud m�xima que aparecen 
  // en el vector.


bool es_num_tcte_max(int a[], int n, int c) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES     
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}

// PROGRAMA DE PRUEBA: NO MODIFICAR


//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//      Valor de c
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        8
//        1 1 1 3 3 2 2 2
//        2
//        5
//        1 2 3 2 4
//        2
//        5
//        1 2 3 2 4
//        5
//        10
//        1 1 0 3 3 0 2 2 0 1
//        3
//        -1
//      SALIDA:
//       true
//       false
//       true
//       true  



const int N = 20; // numero m�ximo de elementos

bool lee_caso(int & n, int a[], int& c) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		cin >> c;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 int c;
	 if (lee_caso(n, a, c)) {
		 cout << std::boolalpha << es_num_tcte_max(a, n ,c) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

