#include "especificapp.h"

#include <iostream>

using namespace std;

// Un vector de enteros es unimodal cuando el m�ximo elemento del vector aparece una �nica vez. Especifica 
// un predicado que, dado un vector no vac�o de n elementos almacenado en las n primeras posiciones de un array a, 
// sea cierto cuando el vector sea unimodal y falso en caso contrario. 


auto es_unimodal(int a[], int n) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}

// PROGRAMA DE PRUEBA: NO MODIFICAR

//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        5
//        1 2 3 4 5
//        5
//        1 5 2 4 5
//        1
//        5
//        3
//        -1 0 -1
//        -1
//      SALIDA:
//       true
//       false
//       true
//       true  



const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[]) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 if (lee_caso(n, a)) {
		 cout << std::boolalpha << es_unimodal(a, n) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

