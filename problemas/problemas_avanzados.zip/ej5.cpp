#include "especificapp.h"

#include <iostream>

using namespace std;

// 5)	Decimos que una secuencia no vac�a de n�meros enteros es minimal cuando su elemento m�nimo aparece una �nica vez. 
// Decimos que una secuencia no vac�a de n�meros enteros es minimalista cuando todas las subsecuencias de elementos consecutivos 
// que contiene que comienzan en el primer elemento son minimales. Por ejemplo, 3,2,3,1 es minimalista, porque las subsecuencias 
// 3
// 3, 2
// 3, 2, 3
// 3, 2, 3, 1
// son todas minimales.Sin embargo, la secuencia 2, 3, 2, 1 no es minimalista porque la subsecuencia 2, 3, 2 no es minimal.
// Especifica un predicado que sea cierto s� y s�lo s� la secuencia almacenada en las n primeras posiciones del array a es minimalista.


bool es_minimalista(int a[], int n) {
    // DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}

//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        4
//        3 2 3 1
//        4
//        2 3 2 1
//        1
//        7
//        5
//        1 3 4 3 3
//        -1
//      SALIDA:
//       true
//       false
//       true
//       true  


// PROGRAMA DE PRUEBA: NO MODIFICAR

const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[]) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 if (lee_caso(n, a)) {
		 cout << std::boolalpha << es_minimalista(a, n) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

