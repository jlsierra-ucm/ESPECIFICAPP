#include "especificapp.h"

#include <iostream>

using namespace std;

// Una secuencia de m�ltiplos es una sucesi�n de n�meros enteros, todos ellos distintos de 0, en las que todos los n�meros, 
// a excepci�n del primero, son divisibles por el anterior. Un ejemplo de este tipo de secuencias es
// 
// 5, 10, 20, 40, 80, 160
//
// Especifica un predicado que, dado un vector de enteros almacenado en las n primeras posiciones de un array a, todos ellos 
// distintos de 0, sea cierto si y s�lo s� el valor almacenado en la variable c coindice con el n�mero de secuencias de m�ltiplos 
// de longitud dada por la variable k(k > 0) que aparecen en dicho vector.


bool num_seq_mult(int a[], int n, int k, int c) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}

//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector 'a'
//      Valor de k
//      Valor de c
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        8
//        9 5 10 20 40 80 160 320
//        4
//        4
//        4
//        2 4 6 12
//        2
//        2
//        4
//        2 4 6 12
//        2
//        3
//        4
//        2 4 6 12
//        1
//        4
//        -1
//      SALIDA:
//       true
//       true
//       false
//       true  


// PROGRAMA DE PRUEBA: NO MODIFICAR

const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int & k, int & c) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		cin >> k;
		cin >> c;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 int k;
	 int c;
	 if (lee_caso(n, a, k, c)) {
		 cout << std::boolalpha << num_seq_mult(a, n, k, c) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

