#include "especificapp.h"

#include <iostream>

using namespace std;

// Dado un vector de enteros, y un entero c > 0, se dice que un tramo (secuencia de valores consecutivos) de dicho vector es un c-tramo cuando la 
// suma de sus elementos es igual a c.
// Especifica un predicado que, dado un vector almacenado en las n primeras posiciones de un array a, y una variable c, sea cierto s� y s�lo s� el vector 
// contiene un c - tramo (siendo c el valor almacenado en la variable c).


bool hay_ct(int a[], int n, int c) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS

}

//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector
//      Valor de c
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        6 
//        1 10 1 2 3 1
//        7
//        5
//        10 10 1 2 3
//        17
//        5
//        1 2 3 4 10
//        9
//        5
//        10 1 2 3 4
//        21
//        -1
//      SALIDA:
//       true
//       false
//       true
//       false  


// PROGRAMA DE PRUEBA: NO MODIFICAR

const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int &c) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		cin >> c;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 int c;
	 if (lee_caso(n, a, c)) {
		 cout << std::boolalpha << hay_ct(a, n, c) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

