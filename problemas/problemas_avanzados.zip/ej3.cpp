#include "especificapp.h"

#include <iostream>

using namespace std;

// Una secuencia de enteros se denomina escalera cuando cada entero, a excepci�n del primero, se obtiene sumando o restando 1 
// al anterior. Por otro lado, la integral de una secuencia de enteros es la suma de los elementos que la forman. Especifica un 
// predicado que, dado un vector no vac�o almacenado en las n primeras posiciones de un array a, sea cierto si y s�lo s� el valor 
// almacenado en la variable m coindice con la mayor integral de todas las escaleras contenidas en el vector.

bool max_integral_escaleras(int a[], int n, int m) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}

//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector
//      Valor de m
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        6
//        5 6 5 3 2 3
//        16
//        4
//        10 12 8 2
//        12
//        4
//        30 30 30 30
//        30
//        4
//        30 30 30 30
//        120
//        -1
//      SALIDA:
//       true
//       true
//       true
//       false  


// PROGRAMA DE PRUEBA: NO MODIFICAR

const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int & m) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		cin >> m;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 int m;
	 if (lee_caso(n, a, m)) {
		 cout << std::boolalpha << max_integral_escaleras(a, n, m) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

