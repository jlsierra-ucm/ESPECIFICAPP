#include "especificapp.h"

#include <iostream>

using namespace std;

// Un ascensor almacena en su memoria la secuencia de plantas en las que para cada d�a. Por ejemplo, 
// la secuencia 0,1,3,1,2,5 describe el comportamiento de un ascensor que comienza en la planta baja del edificio 
// y luego para en las plantas 1, 3, 1, 2 y 5, en ese orden. Si solo nos fijamos en los cambios de direcci�n (no en las paradas intermedias) 
// el ascensor realiza 3 trayectos: primero sube 3 pisos (de la planta 0 a la 3), luego baja 2 pisos (de la 3 a la 1) y finalmente sube 4 pisos 
// (de la 1 a la 5).
// Dada la secuencia de plantas en las que para el ascensor, almacenada en las n primeras posiciones del array a, y dada una variable m, 
// escribe un predicado que sea cierto s� y s�lo s� m contiene la longitud del trayecto m�s largo que ha recorrido el ascensor, entendiendo 
// como tal el m�ximo n�mero de plantas que el ascensor ha recorrido sin cambiar de direcci�n.


bool lon_tray_mas_largo(int a[], int n, int m) {
    // DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}


//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del recorrido
//      Valor de m
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//        2
//        5 3
//        2
//        4
//        4 2 0 3
//        4
//        4
//        4 2 0 3
//        2
//        6
//        0 1 3 1 2 5
//        4
//        8
//        2 4 6 8 3 1 4 5
//        7
//        -1
//      SALIDA:
//       true
//       true
//       false
//       true
//       true 


// PROGRAMA DE PRUEBA: NO MODIFICAR

const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int & m) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		cin >> m;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 int m;
	 if (lee_caso(n, a, m)) {
		 cout << std::boolalpha << lon_tray_mas_largo(a, n, m) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

