#include "especificapp.h"

#include <iostream>

using namespace std;

    // Dado un vector de enteros, se dice que una secuencia de valores consecutivos de v es un tramo par cuando todos los valores son
	// n�meros pares. Especifica un predicado que, dado un vector almacenado en las n primeras posiciones del array a (n >= 0), 
	// sea cierto si y s�lo s� en el vector hay, al menos, un tramo par y el valor de la variable l coincide con la longitud del tramo 
	// par m�s largo de dicho vector. 


bool lon_tp_mas_largo(int a[],  int n, int l) {
	// DEFINE AQUI EL PREDICADO PEDIDO. PUEDES
	// DEFINIR Y UTILIZAR, ASI MISMO, LOS PREDICADOS
	// Y EXPRESIONES AUXILIARES QUE CONSIDERES OPORTUNOS
}


//  Formato de caso:
//    Entrada:
//      Numero de elementos
//      Elem1 ... Elemk del vector
//      Valor de la variable l
//    Salida:
//      El valor del predicado (true o false)
//  Fin de casos: -1
//  Ejemplos
//     ENTRADA:
//       10
//       2 4 5 7 9 6 8 10 12 14
//       5 
//       5 
//       2 4 5 8 10
//       2
//       5
//       2 4 5 8 10
//       3
//       3
//       1 3 5
//       0
//       -1
//      SALIDA:
//       true
//       true
//       false
//       false  


// PROGRAMA DE PRUEBA: NO MODIFICAR

const int N = 20; // numero m�ximo de elementos



bool lee_caso(int & n, int a[], int & l) {
	cin >> n;
	if (n != -1) {
		for (int i = 0; i < n; i++) {
			cin >> a[i];
		}
		cin >> l;
		return true;
	}
	else {
		return false;
	}
}

bool ejecuta_caso() {
	 int a[N];
	 int n;
	 int l;
	 if (lee_caso(n, a, l)) {
		 cout << std::boolalpha << lon_tp_mas_largo(a, n, l) << endl;
		 return true;
	 }
	 else {
		 return false;
	 }
}
 
int main() {
	while (ejecuta_caso());
	return 0;
}

